extends CharacterBody2D

@export var speed: float = 180.0

func _physics_process(_delta):
	# Lấy hướng di chuyển 8 hướng (WASD / Mũi tên)
	var input_direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	
	velocity = input_direction * speed
	move_and_slide()
